﻿using System.Collections.Generic;

namespace practice_4_4;
class Program
{
    static void Main(string[] args)
    {
        List<Shape> shapes = new List<Shape>();
        shapes.Add(new Circle());
        shapes.Add(new Rectangle());
        shapes.Add(new Triangle());
        foreach(Shape shape in shapes)
        {
            shape.Draw();
        }
        Console.ReadKey();
    }
}

