﻿using System;
namespace practice_4_4
{
	public class Shape
	{
		public int X {
			get;
			private set;
		}

		public int Y
		{
			get;
			private set;
		}

		public int Height
		{
			get;
			set;
		}

		public int Width
		{
			get;
			set;
		}

		public Shape()
		{
		}

		public virtual void Draw()
		{
			Console.WriteLine("Print from base class");
		}
	}
}

