﻿using System;
namespace practice_4_4
{
	public class Triangle : Shape
	{

		public Triangle()
		{
		}

        public override void Draw()
        {
            Console.WriteLine("Triangle draw");
            base.Draw();
        }
    }
}

