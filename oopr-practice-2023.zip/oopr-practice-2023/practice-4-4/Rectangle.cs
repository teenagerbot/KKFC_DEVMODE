﻿using System;
namespace practice_4_4
{
	public class Rectangle : Shape
	{
		public Rectangle()
		{
		}

        public override void Draw()
        {
            Console.WriteLine("Rectangle draw"); 
            base.Draw();
        }
    }
}

