﻿using System;
namespace practice_4_4
{
	public class Circle : Shape
	{
		public Circle()
		{ 
		}

		public override void Draw()
		{
			Console.WriteLine("Circle draw");
			base.Draw();
		}
	}
}

