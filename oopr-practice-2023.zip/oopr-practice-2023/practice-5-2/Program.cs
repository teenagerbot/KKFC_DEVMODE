﻿namespace practice_5_2;

delegate string StrMod(string srt);

class Program
{
    static string ReplaceSpaces(string s)
    {
        Console.WriteLine("Replasing spaces with -");
        return s.Replace(" ", "-");
    }
    static string RemoveSpaces(string s)
    {
        string temp = "";
        Console.WriteLine("Remove spaces");
        for (int i = 0; i < s.Length; i++)
        {
            if (s[i] != ' ') temp += s[i];
        }
        return temp;
    }
    static string Reverse(string s)
    {
        string temp = "";
        for (int i = s.Length - 1; i >= 0; i--)
        {
            temp += s[i];
        }
        return temp;
    }

    static void Main(string[] args)
    {
        Console.WriteLine("Hello, World!");
        //StrMod strOp = new StrMod(ReplaceSpaces);
        StrMod strOp = RemoveSpaces;
        StrModq strModq = RemoveSpaces;
        string str = "simple test launched";
        str = strOp(str);
        Console.WriteLine(str);


        //strOp = new StrMod(RemoveSpaces);
        strOp = RemoveSpaces;
        str = strOp("simple test launched");
        Console.WriteLine(str);

        //strOp = new StrMod(Reverse);
        strOp = Reverse;
        str = strOp("simple test launched");
        Console.WriteLine(str);
        Console.ReadKey();
    }
}

