﻿namespace practice_4_2;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Hello, World!");
        Person person = new Person("M", "S", 25);
        Student student = new Student("M", "B", 25, 4);
        Console.WriteLine(person.ShowInfo());
        Console.WriteLine(student.ShowInfo());
        Console.ReadKey();
    }

}

