﻿using System;

namespace practice_4_2
{
    public class Student : Person
    {
        public int course;


        public Student()
        {

        }

        public Student(string firstName, string secondName, int age, int course) : base(firstName, secondName, age)
        {
            this.course = course;
        }


        //usign the new keyword to redefine a new method
        public new string ShowInfo()
        {
            return base.ShowInfo() + $" Course: {course}";
        }
    }
}

