﻿using System;
namespace practice_4_2
{
    public class Person
    {
        public string? firstName;
        public string? secondName;
        public int? age;


        public Person()
        {
        }

        public Person(string firstName, string secondName, int age)
        {
            this.firstName = firstName;
            this.secondName = secondName;
            this.age = age;
        }


        
        public string ShowInfo()
        {
            return $"FirstName: {firstName}, SecondName: {secondName}, Age: {age}";
        }
    }
}

