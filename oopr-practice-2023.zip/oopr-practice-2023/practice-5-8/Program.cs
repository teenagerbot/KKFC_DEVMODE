﻿namespace practice_5_8;
class Program
{
    static void Main(string[] args)
    {
        Func<int, int, double> MultiplyAndGetSqrt = (int a, int b) =>
        {
            double result;
            result = a * b;
            result = Math.Sqrt(result);
            return result;
        };

        Func<int, int, int, List<double>> findX = (int a, int b, int c) =>
        {
            List<double> x12 = new List<double>();
            x12.Add((-b + Math.Sqrt(b * b - 4 * a * c)) / 2 * a);
            x12.Add((-b - Math.Sqrt(b * b - 4 * a * c)) / 2 * a);
            return x12;
        };

        Console.WriteLine(MultiplyAndGetSqrt(10, 20));
        foreach(Double item in findX(10,40,8))
        {
            Console.WriteLine(item);
        };
        Console.ReadKey();
    }
}

