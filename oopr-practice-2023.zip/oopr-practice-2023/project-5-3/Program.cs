﻿namespace practice_5_3;

delegate string StrMod(string s);

class StringOps
{
    public string ReplaceSpaces(string s)
    {
        Console.WriteLine("Replasing spaces with -");
        return s.Replace(" ", "-");
    }
    public string RemoveSpaces(string s)
    {
        string temp = "";
        Console.WriteLine("Remove spaces");
        for (int i = 0; i < s.Length; i++)
        {
            if (s[i] != ' ') temp += s[i];
        }
        return temp;
    }
    public string Reverse(string s)
    {
        string temp = "";
        for (int i = s.Length - 1; i >= 0; i--)
        {
            temp += s[i];
        }
        return temp;
    }
}

class Program
{
    static void Main(string[] args)
    {
        string str;
        StringOps so = new StringOps();
        StrMod strOp = so.ReplaceSpaces;
        str = strOp("This is a simple line");
        Console.WriteLine(str);

        strOp = so.RemoveSpaces;
        str = strOp("This is a simple line");
        Console.WriteLine(str);

        strOp = so.Reverse;
        str = strOp("This is a simple line");
        Console.WriteLine(str);

        Console.ReadLine();
    }
}

