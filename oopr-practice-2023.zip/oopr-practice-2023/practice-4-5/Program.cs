﻿namespace practice_4_5;
class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Hello, World!");
    }
}

public class A
{
    public virtual void Dowork()
    {
        
    }
}

public class B : A
{
    public override void Dowork()
    {

    }
}

public class C : B
{
    public sealed override void Dowork()
    {
        base.Dowork();
    }
}

public class D : C
{
    public new void Dowork()
    {

    }
    //public override void Dowork()
    //{

    //}
}
