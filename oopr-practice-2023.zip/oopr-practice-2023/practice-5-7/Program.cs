﻿namespace practice_5_7;

delegate int IntOp(int end);

class Program
{
    static void Main(string[] args)
    {
        IntOp fact = (int n) =>
        {
            int r = 1;
            for (int i = 1; i <= n; i++)
            {
                r = r * i;
            }
            return r;
        };
        Console.WriteLine($"Factorial for 10 equals: {fact(10)}");

        Func<int> anotherFactorial = () =>
        {
            Console.WriteLine("Enter a number to calculate factorial:");
            int n = int.Parse(Console.ReadLine());

            int result = 1;
            for (int i = 1; i <= n; i++)
            {
                result *= i;
            }
            return result;
        };

        Func<int,int> anotherFactorial2 = (num) =>
        {
            int result = 1;
            for (int i = 1; i <= num; i++)
            {
                result *= i;
            }
            return result;
        };

        Console.WriteLine(anotherFactorial());
        Console.WriteLine(anotherFactorial2(7));
        Console.ReadKey();
    }
}

