﻿using System;
namespace practice_4_3
{
	abstract public class Human
	{
		public int age;

		public Human() 
		{
			
		}

		public Human(int age) 
		{
			this.age = age;
		}

		public abstract string ShowInfo();
		public void sayHello()
		{
			Console.WriteLine("Say Hello");
		}


	}
}

