﻿using System;
namespace practice_4_3
{
    public class Person : Human
    {
        public string? firstName;
        public string? secondName;


        public Person()
        {
        }

        public Person(string firstName, string secondName, int age) : base(age)
        {
            this.firstName = firstName;
            this.secondName = secondName;
        }


        
        public override string ShowInfo()
        {
            return $"FirstName: {firstName}, SecondName: {secondName}, Age: {age}";
        }
    }
}

