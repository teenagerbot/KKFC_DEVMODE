﻿namespace practice_4_3;

internal class Program
{
    private static void Main(string[] args)
    {
        // Human constructor user
        Person person = new Person("M", "S", 25);
        Student student = new Student("M", "B", 25, 4);
        person.sayHello();
        student.sayHello();

        Human human = new Person("M", "S", 33);
        Console.WriteLine(human.GetType());
        human.sayHello();
        Console.ReadKey();

    }
}