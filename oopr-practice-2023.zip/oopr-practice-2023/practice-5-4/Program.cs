﻿namespace practice_5_4;

delegate void StrMod(ref string str);

//Групова адресація - це можливість створити список, або ланцюжок викликів,
//для методів, які викликаються автоматично при зверненні до делегату.
//Створити такий ланцюжок неважко.Для цього достатньо отримати примірник делегата,
//а потім додати методи в ланцюжок за допомогою оператора + або +=.
//Для видалення методу з ланцюжка служить оператор - або -=.
//Якщо делегат повертає значення, то ним стає значення, що повертається
//останнім методом у списку дзвінків.Тому делегат, в якому
//використовується групова адресація, зазвичай має повертається тип void.


class Program
{
    static void ReplaceSpaces(ref string s)
    {
        Console.WriteLine("Replasing spaces with -");
        s = s.Replace(" ", "-");
    }
    static void RemoveSpaces(ref string s)
    {
        string temp = "";
        Console.WriteLine("Remove spaces");
        for (int i = 0; i < s.Length; i++)
        {
            if (s[i] != ' ') temp += s[i];
        }
        s = temp;
    }
    static void Reverse(ref string s)
    {
        Console.WriteLine("Reverse string");
        string temp = "";
        for (int i = s.Length - 1; i >= 0; i--)
        {
            temp += s[i];
        }
        s = temp;
    }

    static void Main(string[] args)
    {
        StrMod strOp;
        StrMod replaceSp = ReplaceSpaces;
        StrMod removeSp = RemoveSpaces;
        StrMod reverseStr = Reverse;
        string str = "this is simple text";
        strOp = replaceSp;
        strOp += reverseStr;
        Console.WriteLine("Resulting str: " + str + "\n");
        strOp += RemoveSpaces;
        strOp(ref str);
        Console.ReadLine();
        //strOp(ref str);
    }
}

