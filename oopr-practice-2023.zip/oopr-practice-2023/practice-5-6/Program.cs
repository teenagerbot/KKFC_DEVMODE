﻿namespace practice_5_6;

delegate int Incr(int v);
delegate bool IsEven(int v);

class Program
{
    static void Main(string[] args)
    {
        Incr incr = count => count + 2;
        Console.WriteLine("Using the => function");
        int x = -10;
        while (x <= 0)
        {
            Console.WriteLine(x + "");
            x = incr(x);
        }
        IsEven isEven = n => n % 2 == 0;
        Console.WriteLine("Using the => function");
        for (int i=1; i<= 10; i++)
        {
            if (isEven(i))
            {
                Console.WriteLine(i + " even");
            }

        }
        Console.ReadKey();
    }
}

