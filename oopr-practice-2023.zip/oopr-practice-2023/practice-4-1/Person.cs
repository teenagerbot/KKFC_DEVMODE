﻿using System;
namespace practice_4_1
{
	public class Person
	{
        public string? firstName;
        public string? secondName;
        public int? age;


        public Person()
		{
		}

		public Person(string firstName,
			string secondName, int age)
		{
			this.firstName = firstName;
			this.secondName = secondName;
			this.age = age;
		}


		//virtual method to be overrided
		public virtual string ShowInfo()
		{
			return $"FirstName: {firstName}, SecondName: {secondName}, Age: {age}";
		}
	}
}

