﻿using System;
namespace practice_4_1
{
	public class Student : Person
	{
		public int course; 


		public Student()
		{
			
		}

		public Student(string firstName, string secondName,
			int age, int course)
			: base(firstName, secondName, age)
		{
			this.course = course;
		}

        public override string ShowInfo()
        {
            return base.ShowInfo() + $" Course: {course}";
        }
    }
}

